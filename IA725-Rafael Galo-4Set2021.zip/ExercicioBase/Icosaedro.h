#pragma once

void CriarIcosaedro(GLuint* VBO, GLuint* IBO);

void SubdividirIcosaedro(int graus);

void CopiarVet2para1();
