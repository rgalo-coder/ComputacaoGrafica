#pragma once

void CriarMesa(GLuint* VBO, GLuint* IBO);
