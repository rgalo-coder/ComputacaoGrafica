#pragma once


extern Vertex VerticesPatches[306];

